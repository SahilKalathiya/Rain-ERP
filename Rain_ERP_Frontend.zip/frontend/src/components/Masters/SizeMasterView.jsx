import React, { useState } from 'react';
import { initialSizeSeries, getStoredData, setStoredData } from '../../data/salesOrderData';

export default function SizeMasterView() {
  const [seriesList, setSeriesList] = useState(() => getStoredData('erp_size_series_v1', initialSizeSeries));
  const [isEditing, setIsEditing] = useState(false);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [activeTab, setActiveTab] = useState('SER-ALPHA');

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    sizesInput: '',
    active: true
  });

  const handleAddNewSeries = () => {
    setFormData({
      id: `SER-${Date.now().toString().slice(-4)}`,
      name: '',
      sizesInput: 'S, M, L, XL, XXL',
      active: true
    });
    setIsCreatingNew(true);
    setIsEditing(true);
  };

  const saveSeries = (e) => {
    e?.preventDefault();
    if (!formData.name.trim()) {
      alert('Series Name is required');
      return;
    }

    const sizesArr = formData.sizesInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const newSeriesObj = {
      id: formData.id || `SER-${Date.now().toString().slice(-4)}`,
      name: formData.name,
      displayOrder: seriesList.length + 1,
      sizes: sizesArr,
      active: formData.active
    };

    let updated;
    if (seriesList.some((s) => s.id === newSeriesObj.id)) {
      updated = seriesList.map((s) => (s.id === newSeriesObj.id ? newSeriesObj : s));
    } else {
      updated = [...seriesList, newSeriesObj];
    }

    setSeriesList(updated);
    setStoredData('erp_size_series_v1', updated);
    setActiveTab(newSeriesObj.id);
    setIsEditing(false);
    setIsCreatingNew(false);
  };

  const activeSeries = seriesList.find((s) => s.id === activeTab) || seriesList[0];

  return (
    <div className="p-4">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 className="fw-bold text-dark mb-1 d-flex align-items-center gap-2">
            <i className="ti ti-ruler text-primary"></i> Size & Size Series Master
          </h4>
          <p className="text-muted small mb-0">Route 1: Manage Alpha (S, M, L), Numeric (32, 34, 36) and Custom Size Sets</p>
        </div>
        {!isEditing && (
          <button className="btn btn-primary d-flex align-items-center gap-2 rounded-3 px-4 fw-semibold" onClick={handleAddNewSeries}>
            <i className="ti ti-plus"></i> Add Size Series
          </button>
        )}
      </div>

      {isEditing ? (
        /* Edit / Create Form */
        <div className="card border-0 shadow-sm rounded-4 mb-4">
          <div className="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h5 className="fw-bold text-dark mb-0">
              {isCreatingNew ? 'Create New Size Series' : `Edit Size Series: ${formData.name}`}
            </h5>
            <button className="btn btn-sm btn-outline-secondary rounded-3" onClick={() => setIsEditing(false)}>
              Cancel
            </button>
          </div>
          <form onSubmit={saveSeries}>
            <div className="card-body p-4">
              <div className="row g-3">
                <div className="col-md-4">
                  <label className="form-label fw-semibold small text-muted">Series ID</label>
                  <input type="text" className="form-control bg-light" value={formData.id} readOnly />
                </div>
                <div className="col-md-8">
                  <label className="form-label fw-semibold small text-muted">Series Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. Alphabetic (S, M, L, XL) or Numeric"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="col-12">
                  <label className="form-label fw-semibold small text-muted">Sizes (Comma separated) *</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="S, M, L, XL, XXL, 3XL"
                    required
                    value={formData.sizesInput}
                    onChange={(e) => setFormData({ ...formData, sizesInput: e.target.value })}
                  />
                  <div className="form-text">Type sizes separated by commas. e.g. "32, 34, 36, 38, 40"</div>
                </div>
              </div>
            </div>
            <div className="card-footer bg-light border-top py-3 px-4 d-flex justify-content-end gap-2">
              <button type="button" className="btn btn-outline-secondary rounded-3 px-4" onClick={() => setIsEditing(false)}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary rounded-3 px-4 fw-semibold">
                <i className="ti ti-check me-1"></i> Save Series
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Series Cards and Tab Navigation */
        <div>
          {/* Series Nav Pills */}
          <div className="d-flex gap-2 mb-4 overflow-auto pb-2">
            {seriesList.map((series) => (
              <button
                key={series.id}
                className={`btn rounded-4 px-4 py-2 fw-semibold transition ${
                  activeTab === series.id ? 'btn-primary shadow-sm' : 'btn-white border text-secondary bg-white'
                }`}
                onClick={() => setActiveTab(series.id)}
              >
                <i className="ti ti-tag me-1"></i> {series.name}
              </button>
            ))}
          </div>

          {/* Active Series Detail Card */}
          {activeSeries && (
            <div className="card border-0 shadow-sm rounded-4 p-4 mb-4">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                  <h5 className="fw-bold text-dark mb-1">{activeSeries.name}</h5>
                  <span className="badge bg-primary-subtle text-primary font-monospace">{activeSeries.id}</span>
                </div>
                <button
                  className="btn btn-outline-primary btn-sm rounded-3 px-3 fw-semibold"
                  onClick={() => {
                    setFormData({
                      id: activeSeries.id,
                      name: activeSeries.name,
                      sizesInput: (activeSeries.sizes || []).join(', '),
                      active: activeSeries.active
                    });
                    setIsCreatingNew(false);
                    setIsEditing(true);
                  }}
                >
                  <i className="ti ti-edit me-1"></i> Edit Sizes
                </button>
              </div>

              <h6 className="fw-semibold text-muted text-uppercase small mb-3">Sizes included in this series:</h6>
              <div className="d-flex flex-wrap gap-3">
                {activeSeries.sizes.map((size, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-light rounded-4 border text-center shadow-xs"
                    style={{ minWidth: '100px' }}
                  >
                    <div className="fw-bold fs-4 text-primary">{size}</div>
                    <div className="text-muted small">Position #{idx + 1}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
