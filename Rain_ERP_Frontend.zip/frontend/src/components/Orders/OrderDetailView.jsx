import React, { useState } from 'react';

export default function OrderDetailView({
  order,
  onBack,
  onEditSection,
  onTriggerProcurement
}) {
  const [activeTab, setActiveTab] = useState('overview');

  if (!order) return null;

  return (
    <div className="p-4">
      {/* Header Bar */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div className="d-flex align-items-center gap-3">
          <button className="btn btn-outline-secondary btn-sm rounded-3 p-2" onClick={onBack}>
            <i className="ti ti-arrow-left fs-5"></i>
          </button>
          <div>
            <div className="d-flex align-items-center gap-2">
              <span className="badge bg-primary-subtle text-primary font-monospace fs-7 px-2 py-1">
                {order.id}
              </span>
              <h4 className="fw-bold text-dark mb-0">{order.styleName}</h4>
            </div>
            <p className="text-muted small mb-0 mt-1">
              Created on {order.createdAt || order.orderDate} by {order.createdBy || 'Admin'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="d-flex gap-2">
          <span className="badge bg-success-subtle text-success fs-7 px-3 py-2 rounded-3 border border-success">
            <i className="ti ti-circle-check me-1"></i> {order.stage || 'Order Confirmed'}
          </span>
          <button className="btn btn-outline-primary btn-sm rounded-3 px-3 fw-semibold" onClick={() => onEditSection('all')}>
            <i className="ti ti-edit me-1"></i> Edit Order
          </button>
        </div>
      </div>

      {/* Navigation Tabs for View */}
      <div className="d-flex gap-2 mb-4 border-bottom pb-2">
        <button
          className={`btn btn-sm rounded-pill px-3 fw-semibold ${activeTab === 'overview' ? 'btn-primary' : 'btn-light'}`}
          onClick={() => setActiveTab('overview')}
        >
          <i className="ti ti-layout-grid me-1"></i> Specifications & Fabrics
        </button>
        <button
          className={`btn btn-sm rounded-pill px-3 fw-semibold ${activeTab === 'matrices' ? 'btn-primary' : 'btn-light'}`}
          onClick={() => setActiveTab('matrices')}
        >
          <i className="ti ti-table me-1"></i> Quantity Matrices ({order.totalGarments || 0} pcs)
        </button>
        <button
          className={`btn btn-sm rounded-pill px-3 fw-semibold ${activeTab === 'accessories' ? 'btn-primary' : 'btn-light'}`}
          onClick={() => setActiveTab('accessories')}
        >
          <i className="ti ti-diamond me-1"></i> Accessories BOM
        </button>
        <button
          className={`btn btn-sm rounded-pill px-3 fw-semibold ${activeTab === 'tracking' ? 'btn-primary' : 'btn-light'}`}
          onClick={() => setActiveTab('tracking')}
        >
          <i className="ti ti-activity me-1"></i> Live Production & QC Tracking
        </button>
      </div>

      {/* Tab 1: Overview & Fabric Consumption */}
      {activeTab === 'overview' && (
        <div className="row g-4 mb-4">
          {/* Section 1: Order Header Info */}
          <div className="col-12">
            <div className="card border-0 shadow-sm rounded-4 p-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                  <i className="ti ti-info-circle text-primary"></i> 1. Order Header Summary
                </h6>
                <button className="btn btn-sm btn-outline-secondary rounded-pill" onClick={() => onEditSection('header')}>
                  <i className="ti ti-edit me-1"></i> Edit Section
                </button>
              </div>
              <div className="row g-3">
                <div className="col-md-3">
                  <div className="text-muted small">Style Name</div>
                  <div className="fw-semibold text-dark fs-6">{order.styleName}</div>
                </div>
                <div className="col-md-3">
                  <div className="text-muted small">Order Date</div>
                  <div className="fw-semibold text-dark">{order.orderDate}</div>
                </div>
                <div className="col-md-3">
                  <div className="text-muted small">Expected Delivery</div>
                  <div className="fw-semibold text-dark">{order.expectedDelivery || 'Not specified'}</div>
                </div>
                <div className="col-md-3">
                  <div className="text-muted small">Priority</div>
                  <span className="badge bg-warning-subtle text-warning border px-2 py-1">{order.priority}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Articles & Customer Assignments */}
          <div className="col-12">
            <div className="card border-0 shadow-sm rounded-4 p-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                  <i className="ti ti-shirt text-primary"></i> 2. Selected Articles & Customers
                </h6>
                <button className="btn btn-sm btn-outline-secondary rounded-pill" onClick={() => onEditSection('articles')}>
                  <i className="ti ti-edit me-1"></i> Edit Section
                </button>
              </div>
              <div className="row g-3">
                <div className="col-md-6">
                  <h6 className="text-muted small fw-bold text-uppercase mb-2">Articles ({order.articles?.length || 0})</h6>
                  <div className="d-flex flex-wrap gap-2">
                    {order.articles?.map((art, idx) => (
                      <div key={idx} className="p-2 px-3 bg-light border rounded-3 d-flex align-items-center gap-2">
                        <span className="fs-5">{art.icon || '👕'}</span>
                        <div>
                          <strong className="text-dark">{art.name}</strong>
                          <div className="text-muted small">Avg Length: {art.avgGarmentLength} in</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="col-md-6">
                  <h6 className="text-muted small fw-bold text-uppercase mb-2">Assigned Customers ({order.customers?.length || 0})</h6>
                  <div className="d-flex flex-wrap gap-2">
                    {order.customers?.map((cust, idx) => (
                      <div key={idx} className="p-2 px-3 bg-light border rounded-3">
                        <strong className="text-dark d-block">{cust.name}</strong>
                        <span className="text-muted small">Articles: {(cust.assignedArticles || []).join(', ') || 'All'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Fabric Consumption Calculation */}
          <div className="col-12">
            <div className="card border-0 shadow-sm rounded-4 p-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                  <i className="ti ti-color-swatch text-primary"></i> 3. Fabric Consumption & Costing Summary
                </h6>
                <button className="btn btn-sm btn-outline-secondary rounded-pill" onClick={() => onEditSection('fabric')}>
                  <i className="ti ti-edit me-1"></i> Edit Section
                </button>
              </div>

              <div className="table-responsive">
                <table className="table table-bordered align-middle">
                  <thead className="bg-light">
                    <tr>
                      <th className="small fw-bold">ARTICLE</th>
                      <th className="small fw-bold">FABRIC QUALITY</th>
                      <th className="small fw-bold">WIDTH</th>
                      <th className="small fw-bold">COLOUR</th>
                      <th className="small fw-bold text-end">CONSUMPTION/PC</th>
                      <th className="small fw-bold text-end">PIECES</th>
                      <th className="small fw-bold text-end">TOTAL DYED</th>
                      <th className="small fw-bold text-end">TOTAL GREIGE</th>
                    </tr>
                  </thead>
                  <tbody>
                    {order.fabricConsumptions?.map((fc, idx) => (
                      <tr key={idx}>
                        <td className="fw-semibold">{fc.articleName}</td>
                        <td>{fc.fabricName}</td>
                        <td>{fc.width}</td>
                        <td>
                          <span className="badge bg-light text-dark border px-2 py-1">{fc.colorName}</span>
                        </td>
                        <td className="text-end font-monospace">{fc.consumptionPerGarment} m</td>
                        <td className="text-end fw-semibold">{fc.pieces}</td>
                        <td className="text-end text-success fw-bold font-monospace">{fc.totalDyed} m</td>
                        <td className="text-end text-primary fw-bold font-monospace">{fc.totalGreige} m</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-light fw-bold">
                    <tr>
                      <td colSpan={5}>Total Requirement</td>
                      <td className="text-end">{order.totalGarments} pcs</td>
                      <td className="text-end text-success">{order.totalFabricDyed} m</td>
                      <td className="text-end text-primary">{order.totalFabricGreige} m</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Quantity Matrices */}
      {activeTab === 'matrices' && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6 className="fw-bold text-dark mb-0">Size Series & Quantity Breakdown</h6>
            <span className="badge bg-primary-subtle text-primary">Ratio: 1:2:2:1</span>
          </div>
          {order.matrices?.map((mat, idx) => (
            <div key={idx} className="mb-4">
              <h6 className="fw-bold text-secondary mb-2">{mat.groupName}</h6>
              <div className="table-responsive">
                <table className="table table-bordered text-center align-middle">
                  <thead className="bg-light">
                    <tr>
                      <th>Color</th>
                      <th>S (100)</th>
                      <th>M (200)</th>
                      <th>L (200)</th>
                      <th>XL (100)</th>
                      <th className="text-primary">Total Pieces</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(mat.quantities || {}).map(([color, q], cIdx) => (
                      <tr key={cIdx}>
                        <td className="fw-bold text-start">{color}</td>
                        <td>{q.S}</td>
                        <td>{q.M}</td>
                        <td>{q.L}</td>
                        <td>{q.XL}</td>
                        <td className="fw-bold text-primary">{q.Total || q.S + q.M + q.L + q.XL}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Accessories BOM */}
      {activeTab === 'accessories' && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6 className="fw-bold text-dark mb-0">Order-Level Accessories Configuration</h6>
            <button className="btn btn-sm btn-outline-secondary rounded-pill" onClick={() => onEditSection('accessories')}>
              <i className="ti ti-edit me-1"></i> Edit BOM
            </button>
          </div>
          {order.accessories?.map((acc, idx) => (
            <div key={idx} className="card border p-3 rounded-3 mb-3 bg-light">
              <div className="d-flex justify-content-between align-items-center mb-2">
                <div>
                  <span className="badge bg-purple-subtle text-purple border px-2 py-1 rounded-pill me-2">
                    {acc.category}
                  </span>
                  <strong className="text-dark fs-6">{acc.varietyName}</strong>
                </div>
                <span className="text-muted small">Applies to: {(acc.appliesTo || []).join(', ')}</span>
              </div>
              <div className="table-responsive bg-white rounded-3">
                <table className="table table-sm table-hover mb-0 align-middle">
                  <thead>
                    <tr>
                      <th>Article</th>
                      <th>Colour</th>
                      <th>Placement</th>
                      <th>Accessory Colour</th>
                      <th>Source</th>
                      <th>Req/Pc</th>
                      <th>Buffer %</th>
                      <th className="text-end">Total Qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    {acc.rows?.map((r, rIdx) => (
                      <tr key={rIdx}>
                        <td>{r.article}</td>
                        <td>{r.articleColor}</td>
                        <td>{r.placement}</td>
                        <td>{r.accessoryColor}</td>
                        <td>{r.source}</td>
                        <td>{r.reqPerPiece}</td>
                        <td>{r.bufferPercent}%</td>
                        <td className="text-end fw-bold text-primary">{r.totalQuantity} {acc.unit}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 4: Live Tracking Panel (Dyeing, GRN, QC) */}
      {activeTab === 'tracking' && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4">
          <h6 className="fw-bold text-dark mb-4 d-flex align-items-center gap-2">
            <i className="ti ti-timeline text-primary"></i> Live Order Tracking & Procurement Flow
          </h6>
          <div className="row g-4">
            {/* Dyeing Tracker */}
            <div className="col-md-4">
              <div className="card border p-3 rounded-4 bg-light h-100">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="fw-bold text-dark mb-0">1. Fabric Dyeing Process</h6>
                  <span className="badge bg-warning-subtle text-warning">In Progress</span>
                </div>
                <div className="small text-muted mb-2">Meters Sent: <strong>{order.totalFabricGreige} m</strong></div>
                <div className="small text-muted mb-2">Vendor: <strong>Surat Rayon & Silk Mills</strong></div>
                <div className="small text-muted">Expected Return: <strong>{order.tracking?.fabricDyeing?.expectedReturn || '2026-10-18'}</strong></div>
              </div>
            </div>

            {/* GRN Inward Tracker */}
            <div className="col-md-4">
              <div className="card border p-3 rounded-4 bg-light h-100">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="fw-bold text-dark mb-0">2. Goods Receipt (GRN)</h6>
                  <span className="badge bg-info-subtle text-info">1 GRN Inwarded</span>
                </div>
                <div className="small text-muted mb-2">Bale Count: <strong>4 Bales Received</strong></div>
                <div className="small text-muted mb-2">Meters Logged: <strong>1,200 / {order.totalFabricGreige} m</strong></div>
                <div className="small text-muted">Status: <strong>Bale Entry Verified</strong></div>
              </div>
            </div>

            {/* QC Checks Tracker */}
            <div className="col-md-4">
              <div className="card border p-3 rounded-4 bg-light h-100">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="fw-bold text-dark mb-0">3. Quality Inspection (QC)</h6>
                  <span className="badge bg-success-subtle text-success">QC Passed</span>
                </div>
                <div className="small text-muted mb-2">Checks Completed: <strong>1 Batch Check</strong></div>
                <div className="small text-muted mb-2">Result: <strong>Grade A (Clean)</strong></div>
                <div className="small text-muted">Rejected Stock: <strong>0 meters</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
       * BASKET ACTION BAR (Bottom Procurement Handoff - Section 9 of PDF)
       * ========================================================================= */}
      <div className="card border-0 shadow-lg rounded-4 p-3 bg-dark text-white d-flex flex-row justify-content-between align-items-center flex-wrap gap-3">
        <div className="d-flex align-items-center gap-3">
          <div className="p-2 bg-primary rounded-3 text-white fs-4">
            <i className="ti ti-shopping-cart"></i>
          </div>
          <div>
            <h6 className="fw-bold mb-0 text-white">Procurement Basket Handoff</h6>
            <span className="text-light opacity-75 small">
              {order.totalFabricGreige}m Greige Fabric &bull; {order.totalGarments} pcs &bull; Accessories Configured
            </span>
          </div>
        </div>
        <div className="d-flex gap-2">
          <button
            className="btn btn-primary rounded-3 px-3 fw-semibold d-flex align-items-center gap-2 shadow-sm"
            onClick={() => onTriggerProcurement('Create PO', order)}
          >
            <i className="ti ti-file-text"></i> Create PO
          </button>
          <button
            className="btn btn-outline-light rounded-3 px-3 fw-semibold d-flex align-items-center gap-2"
            onClick={() => onTriggerProcurement('Send to Process', order)}
          >
            <i className="ti ti-brush"></i> Send to Process
          </button>
          <button
            className="btn btn-outline-light rounded-3 px-3 fw-semibold d-flex align-items-center gap-2"
            onClick={() => onTriggerProcurement('Order Material', order)}
          >
            <i className="ti ti-box"></i> Order Material
          </button>
        </div>
      </div>
    </div>
  );
}
