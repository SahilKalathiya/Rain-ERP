import React, { useState } from 'react';
import OrdersListView from './OrdersListView';
import OrderDetailView from './OrderDetailView';
import OrderCreationWizard from './OrderCreationWizard';
import { initialSalesOrders, getStoredData, setStoredData } from '../../data/salesOrderData';

export default function OrdersModule({ onNavigateToProcurement }) {
  const [viewMode, setViewMode] = useState('list'); // 'list' | 'detail' | 'create'
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [orders, setOrders] = useState(() => getStoredData('erp_sales_orders_v1', initialSalesOrders));

  const handleNewOrder = () => {
    setSelectedOrder(null);
    setViewMode('create');
  };

  const handleViewOrder = (order) => {
    setSelectedOrder(order);
    setViewMode('detail');
  };

  const handleEditOrder = (order) => {
    setSelectedOrder(order);
    setViewMode('create');
  };

  const handleSaveOrder = (newOrder, action) => {
    const updated = [newOrder, ...orders.filter((o) => o.id !== newOrder.id)];
    setOrders(updated);
    setStoredData('erp_sales_orders_v1', updated);

    if (action === 'Create PO' && onNavigateToProcurement) {
      onNavigateToProcurement('/procurement-pos', newOrder);
    } else {
      setSelectedOrder(newOrder);
      setViewMode('detail');
    }
  };

  const handleTriggerProcurement = (actionType, order) => {
    if (actionType === 'Create PO') {
      alert(`🚀 Auto-populating PO for Order #${order.id} with ${order.totalFabricGreige}m Greige Fabric!`);
      if (onNavigateToProcurement) {
        onNavigateToProcurement('/procurement-pos', order);
      }
    } else if (actionType === 'Send to Process') {
      alert(`🎨 Sending ${order.totalFabricGreige}m Greige Fabric to Dyeing Process for ${order.styleName}!`);
    } else {
      alert(`📦 Material Request & Accessories Order generated for ${order.styleName}!`);
    }
  };

  if (viewMode === 'create') {
    return (
      <OrderCreationWizard
        onSaveOrder={handleSaveOrder}
        onCancel={() => setViewMode(selectedOrder ? 'detail' : 'list')}
      />
    );
  }

  if (viewMode === 'detail' && selectedOrder) {
    return (
      <OrderDetailView
        order={selectedOrder}
        onBack={() => setViewMode('list')}
        onEditSection={(section) => {
          setViewMode('create');
        }}
        onTriggerProcurement={handleTriggerProcurement}
      />
    );
  }

  return (
    <OrdersListView
      onNewOrder={handleNewOrder}
      onViewOrder={handleViewOrder}
      onEditOrder={handleEditOrder}
    />
  );
}
