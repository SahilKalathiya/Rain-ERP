import React, { useState, useMemo } from 'react';
import {
  initialArticles,
  initialCustomers,
  initialColors,
  initialSizeSeries,
  initialAccessoryMasters,
  getStoredData,
  setStoredData
} from '../../data/salesOrderData';
import CustomerMasterView from '../Masters/CustomerMasterView';
import ArticleMasterView from '../Masters/ArticleMasterView';

const ALL_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'S/M', 'L/XL', '2XL/3XL', '2XL', '3XL', '4XL', '5XL', '40', '42', '44', '46'];

const ALL_18_COLORS = [
  { name: 'Charcoal', hex: '#333333' },
  { name: 'Green', hex: '#228B22' },
  { name: 'Ivory', hex: '#FFFFF0' },
  { name: 'Jamun', hex: '#4B0082' },
  { name: 'Lavendar', hex: '#8B5CF6' },
  { name: 'Maroon', hex: '#800000' },
  { name: 'Navy Blue', hex: '#000080' },
  { name: 'Pastel Red', hex: '#FF6961' },
  { name: 'Pastel red', hex: '#FA8072' },
  { name: 'Rama Green', hex: '#20B2AA' },
  { name: 'Red', hex: '#DC2626' },
  { name: 'Rust', hex: '#C2410C' },
  { name: 'Rust Light', '#B7410E': '#B7410E', hex: '#EA580C' },
  { name: 'Sea Green', hex: '#2E8B57' },
  { name: 'Teal', hex: '#0D9488' },
  { name: 'Watermelon', hex: '#FC6C85' },
  { name: 'Wine', hex: '#722F37' },
  { name: 'Yellow', hex: '#FEF08A' }
];

export default function OrderCreationWizard({ onSaveOrder, onCancel }) {
  // Master Datasets
  const [allArticles] = useState(() => getStoredData('erp_articles_v1', initialArticles));
  const [allCustomers, setAllCustomers] = useState(() => getStoredData('erp_customers_v1', initialCustomers));

  // Inline Modals
  const [showNewCustomerModal, setShowNewCustomerModal] = useState(false);
  const [showNewArticleModal, setShowNewArticleModal] = useState(false);

  // ==========================================
  // SECTION 1: ORDER HEADER
  // ==========================================
  const [orderHeader, setOrderHeader] = useState({
    id: `ORD-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 900) + 100)}`,
    styleName: '',
    orderDate: new Date().toISOString().split('T')[0],
    expectedDelivery: '',
    priority: 'Normal',
    sizeSeriesId: 'SER-ALPHA'
  });

  // ==========================================
  // SECTION 2: ARTICLES & FABRICS
  // ==========================================
  const [selectedArticles, setSelectedArticles] = useState([]);

  const toggleArticle = (art) => {
    if (selectedArticles.some((a) => a.id === art.id)) {
      setSelectedArticles(selectedArticles.filter((a) => a.id !== art.id));
    } else {
      setSelectedArticles([
        ...selectedArticles,
        {
          id: art.id,
          name: art.name,
          icon: art.icon || '👕',
          avgGarmentLength: '',
          numberOfFabricPieces: 1,
          fabrics: [
            {
              pieceLabel: 'Main Body',
              fabricQuality: '',
              width: '44"',
              shrinkagePercent: '',
              bufferPercent: '',
              fabricRate: '',
              dyedRate: ''
            }
          ]
        }
      ]);
    }
  };

  const updateArticleLength = (artId, length) => {
    setSelectedArticles(
      selectedArticles.map((a) => (a.id === artId ? { ...a, avgGarmentLength: length } : a))
    );
  };

  const updateArticlePiecesCount = (artId, count) => {
    const num = Math.max(1, parseInt(count, 10) || 1);
    setSelectedArticles(
      selectedArticles.map((a) => {
        if (a.id !== artId) return a;
        let currentFabrics = [...(a.fabrics || [])];
        while (currentFabrics.length < num) {
          currentFabrics.push({
            pieceLabel: `Piece #${currentFabrics.length + 1}`,
            fabricQuality: '',
            width: '44"',
            shrinkagePercent: '',
            bufferPercent: '',
            fabricRate: '',
            dyedRate: ''
          });
        }
        if (currentFabrics.length > num) {
          currentFabrics = currentFabrics.slice(0, num);
        }
        return { ...a, numberOfFabricPieces: num, fabrics: currentFabrics };
      })
    );
  };

  // ==========================================
  // SECTION 3: CUSTOMERS & ORDERS (Exact Live UI Structure)
  // ==========================================
  const [customerCount, setCustomerCount] = useState(0);
  const [expandedCustomerIdx, setExpandedCustomerIdx] = useState(0);

  // Each customer stores: customerId, customName, assignedArticles, selectedColors, colorConfigs: { [color]: { useSets, setQty, activeSizes, sizeQtys: { [size]: qty } } }
  const [customerOrders, setCustomerOrders] = useState([]);

  const handleCustomerCountChange = (count) => {
    setCustomerCount(count);
    let updated = [...customerOrders];
    while (updated.length < count) {
      updated.push({
        customerId: '',
        customName: '',
        assignedArticles: selectedArticles.map((a) => a.name),
        selectedColors: [],
        colorConfigs: {}
      });
    }
    if (updated.length > count) {
      updated = updated.slice(0, count);
    }
    setCustomerOrders(updated);
    setExpandedCustomerIdx(0);
  };

  const updateCustomerField = (cIdx, field, value) => {
    setCustomerOrders(
      customerOrders.map((cust, idx) => (idx === cIdx ? { ...cust, [field]: value } : cust))
    );
  };

  const toggleCustomerArticle = (cIdx, artName) => {
    const cust = customerOrders[cIdx];
    const current = cust.assignedArticles || [];
    const updatedArticles = current.includes(artName)
      ? current.filter((a) => a !== artName)
      : [...current, artName];
    updateCustomerField(cIdx, 'assignedArticles', updatedArticles);
  };

  const toggleCustomerColor = (cIdx, colorName) => {
    const cust = customerOrders[cIdx];
    const currentColors = cust.selectedColors || [];
    let newColors;
    let newConfigs = { ...cust.colorConfigs };

    if (currentColors.includes(colorName)) {
      newColors = currentColors.filter((c) => c !== colorName);
      delete newConfigs[colorName];
    } else {
      newColors = [...currentColors, colorName];
      if (!newConfigs[colorName]) {
        newConfigs[colorName] = {
          useSets: false,
          setQty: '',
          activeSizes: [],
          sizeQtys: {}
        };
      }
    }

    setCustomerOrders(
      customerOrders.map((c, idx) =>
        idx === cIdx ? { ...c, selectedColors: newColors, colorConfigs: newConfigs } : c
      )
    );
  };

  const updateColorConfig = (cIdx, colorName, updates) => {
    setCustomerOrders(
      customerOrders.map((cust, idx) => {
        if (idx !== cIdx) return cust;
        const currentConfig = cust.colorConfigs[colorName] || {
          useSets: false,
          setQty: '',
          activeSizes: [],
          sizeQtys: {}
        };
        return {
          ...cust,
          colorConfigs: {
            ...cust.colorConfigs,
            [colorName]: { ...currentConfig, ...updates }
          }
        };
      })
    );
  };

  const toggleColorSize = (cIdx, colorName, size) => {
    const cust = customerOrders[cIdx];
    const config = cust.colorConfigs[colorName] || {
      useSets: false,
      setQty: '',
      activeSizes: [],
      sizeQtys: {}
    };
    const activeSizes = config.activeSizes || [];
    let newActiveSizes;
    let newSizeQtys = { ...config.sizeQtys };

    if (activeSizes.includes(size)) {
      newActiveSizes = activeSizes.filter((s) => s !== size);
      delete newSizeQtys[size];
    } else {
      newActiveSizes = [...activeSizes, size];
      const initialQty = config.useSets && config.setQty ? parseInt(config.setQty, 10) || 0 : 0;
      newSizeQtys[size] = initialQty;
    }

    updateColorConfig(cIdx, colorName, {
      activeSizes: newActiveSizes,
      sizeQtys: newSizeQtys
    });
  };

  const updateSizeQty = (cIdx, colorName, size, deltaOrVal, isDelta = false) => {
    const cust = customerOrders[cIdx];
    const config = cust.colorConfigs[colorName] || { sizeQtys: {} };
    const currentQty = parseInt(config.sizeQtys[size], 10) || 0;
    const newQty = isDelta ? Math.max(0, currentQty + deltaOrVal) : Math.max(0, parseInt(deltaOrVal, 10) || 0);

    updateColorConfig(cIdx, colorName, {
      sizeQtys: {
        ...config.sizeQtys,
        [size]: newQty
      }
    });
  };

  const removeSize = (cIdx, colorName, size) => {
    const cust = customerOrders[cIdx];
    const config = cust.colorConfigs[colorName];
    if (!config) return;
    const newActive = (config.activeSizes || []).filter((s) => s !== size);
    const newQtys = { ...config.sizeQtys };
    delete newQtys[size];
    updateColorConfig(cIdx, colorName, { activeSizes: newActive, sizeQtys: newQtys });
  };

  // Helper: compute total pieces for a customer
  const getCustomerSummary = (cust) => {
    const articlesCount = (cust.assignedArticles || []).length;
    const colorsCount = (cust.selectedColors || []).length;
    let totalPcs = 0;

    Object.values(cust.colorConfigs || {}).forEach((cfg) => {
      Object.values(cfg.sizeQtys || {}).forEach((q) => {
        totalPcs += parseInt(q, 10) || 0;
      });
    });

    return { articlesCount, colorsCount, totalPcs };
  };

  // Overall Total Garment Pieces across all customers
  const grandTotalGarmentPieces = useMemo(() => {
    let sum = 0;
    customerOrders.forEach((cust) => {
      Object.values(cust.colorConfigs || {}).forEach((cfg) => {
        Object.values(cfg.sizeQtys || {}).forEach((q) => {
          sum += parseInt(q, 10) || 0;
        });
      });
    });
    return sum;
  }, [customerOrders]);

  // Aggregate matrix by color for Section 5
  const aggregateColorMatrix = useMemo(() => {
    const matrix = {};
    customerOrders.forEach((cust) => {
      Object.entries(cust.colorConfigs || {}).forEach(([col, cfg]) => {
        if (!matrix[col]) matrix[col] = { Total: 0 };
        Object.entries(cfg.sizeQtys || {}).forEach(([sz, qty]) => {
          const num = parseInt(qty, 10) || 0;
          matrix[col][sz] = (matrix[col][sz] || 0) + num;
          matrix[col].Total += num;
        });
      });
    });
    return matrix;
  }, [customerOrders]);

  // ==========================================
  // SECTION 6: FABRIC CONSUMPTION
  // ==========================================
  const fabricConsumptions = useMemo(() => {
    const list = [];
    selectedArticles.forEach((art) => {
      art.fabrics?.forEach((fab) => {
        Object.entries(aggregateColorMatrix).forEach(([col, szData]) => {
          const colorPieces = szData.Total || 0;
          const shrinkage = parseFloat(fab.shrinkagePercent) || 0;
          const buffer = parseFloat(fab.bufferPercent) || 0;
          const avgLenMeters = ((parseFloat(art.avgGarmentLength) || 0) * 0.0254);
          const consumptionPerGarment = avgLenMeters > 0 ? Number((avgLenMeters * 1.4).toFixed(2)) : 0;

          const greigePerGarment = consumptionPerGarment * (1 + shrinkage / 100) * (1 + buffer / 100);
          const totalDyed = Number((consumptionPerGarment * colorPieces).toFixed(1));
          const totalGreige = Number((greigePerGarment * colorPieces).toFixed(1));

          list.push({
            articleName: art.name,
            fabricQuality: fab.fabricQuality || '—',
            width: fab.width,
            colorName: col,
            consumptionPerGarment,
            pieces: colorPieces,
            shrinkagePercent: shrinkage,
            totalDyed,
            totalGreige,
            fabricRate: parseFloat(fab.fabricRate) || 0,
            dyedRate: parseFloat(fab.dyedRate) || 0
          });
        });
      });
    });
    return list;
  }, [selectedArticles, aggregateColorMatrix]);

  const totalGreigeFabric = useMemo(() => {
    return fabricConsumptions.reduce((acc, cur) => acc + (cur.totalGreige || 0), 0).toFixed(1);
  }, [fabricConsumptions]);

  const totalDyedFabric = useMemo(() => {
    return fabricConsumptions.reduce((acc, cur) => acc + (cur.totalDyed || 0), 0).toFixed(1);
  }, [fabricConsumptions]);

  // ==========================================
  // SECTION 6: ACCESSORIES SELECTION & CONFIGURATION (BOM)
  // ==========================================
  const availableAccessoryPresets = [
    { category: 'Buttons', name: 'Coconut Button (Natural) [14L]', unit: 'Pcs', consumption: 5, bufferPercent: 5, rate: 1.25 },
    { category: 'Buttons', name: 'MOP Button (Pearl White) [16L]', unit: 'Pcs', consumption: 6, bufferPercent: 5, rate: 2.50 },
    { category: 'Buttons', name: 'Eyelet Gold Button [18L]', unit: 'Pcs', consumption: 4, bufferPercent: 5, rate: 3.80 },
    { category: 'Lace', name: 'Cotton Crochet Lace 18mm', unit: 'Mtr', consumption: 1.5, bufferPercent: 5, rate: 14.0 },
    { category: 'Lace', name: 'Zari Border 2 inch', unit: 'Mtr', consumption: 2.0, bufferPercent: 5, rate: 28.0 },
    { category: 'Tassels', name: 'Ready Made Silk Latkan (2 inch)', unit: 'Pcs', consumption: 2, bufferPercent: 2, rate: 18.0 },
    { category: 'Dori', name: 'Matching Fabric Dori', unit: 'Mtr', consumption: 1.2, bufferPercent: 5, rate: 6.0 },
    { category: 'Thread', name: 'Vardhman Poly Reel (6000m Box)', unit: 'Box', consumption: 0.1, bufferPercent: 10, rate: 180.0 },
    { category: 'Thread', name: 'Coats Astra Golden Zari Cone', unit: 'Cone', consumption: 0.05, bufferPercent: 5, rate: 240.0 },
    { category: 'Elastic', name: '1 inch Woven Waistband Elastic', unit: 'Mtr', consumption: 0.85, bufferPercent: 5, rate: 8.50 },
    { category: 'Labels', name: 'Main Woven Brand Label', unit: 'Pcs', consumption: 1, bufferPercent: 2, rate: 2.20 },
    { category: 'Labels', name: 'Wash Care Satin Label', unit: 'Pcs', consumption: 1, bufferPercent: 2, rate: 1.10 },
    { category: 'Tags', name: 'Product Price Tag with Barcode', unit: 'Pcs', consumption: 1, bufferPercent: 2, rate: 1.50 },
    { category: 'Zipper', name: 'YKK Invisible Nylon Zipper 12"', unit: 'Pcs', consumption: 1, bufferPercent: 3, rate: 12.0 },
    { category: 'Packaging', name: 'Polybag with Self-Adhesive Tape', unit: 'Pcs', consumption: 1, bufferPercent: 2, rate: 3.50 }
  ];

  const [orderAccessories, setOrderAccessories] = useState([
    {
      id: 'ACC-1',
      category: 'Buttons',
      name: 'Coconut Button (Natural) [14L]',
      articleName: 'Kurta',
      colorMapping: 'ALL',
      unit: 'Pcs',
      consumptionPerGarment: 5,
      bufferPercent: 5,
      rate: 1.25
    },
    {
      id: 'ACC-2',
      category: 'Labels',
      name: 'Main Woven Brand Label',
      articleName: 'Kurta',
      colorMapping: 'ALL',
      unit: 'Pcs',
      consumptionPerGarment: 1,
      bufferPercent: 2,
      rate: 2.20
    },
    {
      id: 'ACC-3',
      category: 'Thread',
      name: 'Vardhman Poly Reel (6000m Box)',
      articleName: 'Kurta',
      colorMapping: 'ALL',
      unit: 'Box',
      consumptionPerGarment: 0.05,
      bufferPercent: 10,
      rate: 180.0
    }
  ]);

  const [showBomSection, setShowBomSection] = useState(false);
  const [selectedAccessoryCategory, setSelectedAccessoryCategory] = useState('All');

  const addAccessoryRow = (preset) => {
    const newRow = {
      id: `ACC-ROW-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      category: preset?.category || 'Buttons',
      name: preset?.name || 'Custom Accessory Item',
      articleName: selectedArticles.length > 0 ? selectedArticles[0].name : 'All Articles',
      colorMapping: 'ALL',
      unit: preset?.unit || 'Pcs',
      consumptionPerGarment: preset?.consumption || 1,
      bufferPercent: preset?.bufferPercent || 5,
      rate: preset?.rate || 0
    };
    setOrderAccessories([...orderAccessories, newRow]);
  };

  const updateAccessoryRow = (id, field, value) => {
    setOrderAccessories(
      orderAccessories.map((acc) => (acc.id === id ? { ...acc, [field]: value } : acc))
    );
  };

  const removeAccessoryRow = (id) => {
    setOrderAccessories(orderAccessories.filter((acc) => acc.id !== id));
  };

  const calculatedAccessories = useMemo(() => {
    return orderAccessories.map((acc) => {
      let targetPieces = 0;
      if (acc.colorMapping === 'ALL') {
        targetPieces = grandTotalGarmentPieces;
      } else {
        targetPieces = aggregateColorMatrix[acc.colorMapping]?.Total || 0;
      }
      const cons = parseFloat(acc.consumptionPerGarment) || 0;
      const buf = parseFloat(acc.bufferPercent) || 0;
      const rate = parseFloat(acc.rate) || 0;

      const baseQty = targetPieces * cons;
      const totalRequired = Number((baseQty * (1 + buf / 100)).toFixed(1));
      const totalAmount = Number((totalRequired * rate).toFixed(2));

      return {
        ...acc,
        targetPieces,
        totalRequired,
        totalAmount
      };
    });
  }, [orderAccessories, grandTotalGarmentPieces, aggregateColorMatrix]);

  const totalAccessoriesCost = useMemo(() => {
    return calculatedAccessories.reduce((sum, item) => sum + (item.totalAmount || 0), 0).toFixed(2);
  }, [calculatedAccessories]);

  // ==========================================
  // SAVE ORDER & BASKET
  // ==========================================
  const handleFinalSave = (action = 'Save Order') => {
    if (!orderHeader.styleName.trim()) {
      alert('Please enter Style Name');
      return;
    }
    if (selectedArticles.length === 0) {
      alert('Please select at least one Article');
      return;
    }

    const orderPayload = {
      ...orderHeader,
      sizeSeriesName: 'Custom Size Set',
      status: 'Confirmed',
      stage: action === 'Create PO' ? 'PO Generated' : 'Order Created',
      totalGarments: grandTotalGarmentPieces,
      totalFabricGreige: parseFloat(totalGreigeFabric) || 0,
      totalFabricDyed: parseFloat(totalDyedFabric) || 0,
      totalAccessoriesCost: parseFloat(totalAccessoriesCost) || 0,
      estimatedCost: ((parseFloat(totalGreigeFabric) || 0) * 35.0) + (parseFloat(totalAccessoriesCost) || 0),
      createdAt: new Date().toLocaleString(),
      createdBy: 'Saksham Garg',
      articles: selectedArticles,
      customerOrders,
      fabricConsumptions,
      accessories: calculatedAccessories
    };

    const savedOrders = getStoredData('erp_sales_orders_v1', []);
    const updated = [orderPayload, ...savedOrders];
    setStoredData('erp_sales_orders_v1', updated);

    if (onSaveOrder) {
      onSaveOrder(orderPayload, action);
    }
  };

  return (
    <div className="p-4" style={{ background: '#f8fafc', minHeight: '100vh' }}>
      {/* Top Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold text-dark mb-1 d-flex align-items-center gap-2">
            <i className="ti ti-file-plus text-primary"></i> Order Detail Creation
          </h4>
          <p className="text-muted small mb-0">Build style orders: articles, customers, seasonal colors, matrices, BOM & procurement</p>
        </div>
        <div className="d-flex gap-2">
          <button className="btn btn-outline-secondary rounded-3 px-3" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-primary rounded-3 px-4 fw-semibold shadow-sm" onClick={() => handleFinalSave('Save Order')}>
            <i className="ti ti-check me-1"></i> Save Order
          </button>
        </div>
      </div>

      {/* =========================================================================
       * 1. ORDER INFORMATION (HEADER)
       * ========================================================================= */}
      <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
            <span className="badge bg-primary text-white rounded-circle p-1">1</span> Order Information
          </h6>
          <span className="badge bg-light text-muted font-monospace">{orderHeader.id}</span>
        </div>
        <div className="row g-3">
          <div className="col-md-4">
            <label className="form-label fw-semibold small text-muted">Style Name *</label>
            <input
              type="text"
              className="form-control"
              placeholder="e.g. Ikkat Black Kurta Set"
              required
              value={orderHeader.styleName}
              onChange={(e) => setOrderHeader({ ...orderHeader, styleName: e.target.value })}
            />
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold small text-muted">Order Date *</label>
            <input
              type="date"
              className="form-control"
              value={orderHeader.orderDate}
              onChange={(e) => setOrderHeader({ ...orderHeader, orderDate: e.target.value })}
            />
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold small text-muted">Expected Delivery</label>
            <input
              type="date"
              className="form-control"
              value={orderHeader.expectedDelivery}
              onChange={(e) => setOrderHeader({ ...orderHeader, expectedDelivery: e.target.value })}
            />
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold small text-muted">Priority *</label>
            <select
              className="form-select"
              value={orderHeader.priority}
              onChange={(e) => setOrderHeader({ ...orderHeader, priority: e.target.value })}
            >
              <option value="Normal">Normal</option>
              <option value="High">High</option>
              <option value="Urgent">Urgent</option>
            </select>
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold small text-muted">Size Series</label>
            <select
              className="form-select"
              value={orderHeader.sizeSeriesId}
              onChange={(e) => setOrderHeader({ ...orderHeader, sizeSeriesId: e.target.value })}
            >
              <option value="SER-ALPHA">Alphabetic (S, M, L, XL)</option>
              <option value="SER-NUM">Numeric (32, 34, 36, 38)</option>
            </select>
          </div>
        </div>
      </div>

      {/* =========================================================================
       * 2. ARTICLE SELECTION & FABRIC CONFIGURATION
       * ========================================================================= */}
      <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
            <span className="badge bg-primary text-white rounded-circle p-1">2</span> Article Selection & Fabric Configuration
          </h6>
          <span className="text-muted small">Select article types (each can only be added once)</span>
        </div>

        {/* Article Grid Tiles */}
        <div className="row g-2 mb-4">
          {allArticles.map((art) => {
            const isSelected = selectedArticles.some((a) => a.id === art.id);
            return (
              <div key={art.id} className="col-4 col-md-2">
                <div
                  className={`p-3 rounded-4 text-center border transition ${
                    isSelected ? 'border-primary bg-primary-subtle text-primary shadow-xs' : 'bg-light text-secondary'
                  }`}
                  style={{ cursor: 'pointer' }}
                  onClick={() => toggleArticle(art)}
                >
                  <div className="fs-3 mb-1">{art.icon || '👕'}</div>
                  <div className="fw-bold small">{art.name}</div>
                  {isSelected && <i className="ti ti-check text-primary small mt-1"></i>}
                </div>
              </div>
            );
          })}
          <div className="col-4 col-md-2">
            <div
              className="p-3 rounded-4 text-center border border-dashed bg-white text-muted d-flex flex-column justify-content-center align-items-center h-100"
              style={{ cursor: 'pointer' }}
              onClick={() => setShowNewArticleModal(true)}
            >
              <i className="ti ti-plus fs-4 text-primary"></i>
              <span className="small fw-semibold text-primary">+ New Article</span>
            </div>
          </div>
        </div>

        {/* Fabric Requirement per selected article */}
        {selectedArticles.length > 0 ? (
          <div>
            <h6 className="fw-bold text-muted text-uppercase small mb-3">Configure Garment Length & Fabric Requirement:</h6>
            {selectedArticles.map((art) => (
              <div key={art.id} className="p-3 bg-light rounded-4 border mb-3">
                <div className="row g-3 align-items-center">
                  <div className="col-md-3">
                    <div className="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                      <span className="fs-4">{art.icon}</span> {art.name}
                    </div>
                  </div>
                  <div className="col-md-3">
                    <label className="form-label small text-muted mb-1">Average Garment Length (inches) *</label>
                    <input
                      type="text"
                      className="form-control form-control-sm bg-white"
                      placeholder="e.g. 42"
                      value={art.avgGarmentLength}
                      onChange={(e) => updateArticleLength(art.id, e.target.value)}
                    />
                  </div>
                  <div className="col-md-3">
                    <label className="form-label small text-muted mb-1">How many fabrics for this article?</label>
                    <input
                      type="number"
                      min={1}
                      max={5}
                      className="form-control form-control-sm bg-white"
                      placeholder="1"
                      value={art.numberOfFabricPieces}
                      onChange={(e) => updateArticlePiecesCount(art.id, e.target.value)}
                    />
                  </div>
                </div>

                <div className="mt-3 pt-3 border-top">
                  {art.fabrics?.map((fab, fIdx) => (
                    <div key={fIdx} className="row g-2 align-items-center mb-2">
                      <div className="col-md-2">
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          placeholder="Piece Label (e.g. Outer)"
                          value={fab.pieceLabel}
                          onChange={(e) => {
                            const updated = [...art.fabrics];
                            updated[fIdx].pieceLabel = e.target.value;
                            setSelectedArticles(selectedArticles.map((a) => (a.id === art.id ? { ...a, fabrics: updated } : a)));
                          }}
                        />
                      </div>
                      <div className="col-md-3">
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          placeholder="Fabric Quality (e.g. 100/100 Mulmul)"
                          value={fab.fabricQuality}
                          onChange={(e) => {
                            const updated = [...art.fabrics];
                            updated[fIdx].fabricQuality = e.target.value;
                            setSelectedArticles(selectedArticles.map((a) => (a.id === art.id ? { ...a, fabrics: updated } : a)));
                          }}
                        />
                      </div>
                      <div className="col-md-2">
                        <select
                          className="form-select form-select-sm"
                          value={fab.width}
                          onChange={(e) => {
                            const updated = [...art.fabrics];
                            updated[fIdx].width = e.target.value;
                            setSelectedArticles(selectedArticles.map((a) => (a.id === art.id ? { ...a, fabrics: updated } : a)));
                          }}
                        >
                          <option value='44"'>44" Width</option>
                          <option value='47"'>47" Width</option>
                          <option value='48"'>48" Width</option>
                          <option value='58"'>58" Width</option>
                        </select>
                      </div>
                      <div className="col-md-2">
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          placeholder="Shrinkage % (e.g. 4)"
                          value={fab.shrinkagePercent}
                          onChange={(e) => {
                            const updated = [...art.fabrics];
                            updated[fIdx].shrinkagePercent = e.target.value;
                            setSelectedArticles(selectedArticles.map((a) => (a.id === art.id ? { ...a, fabrics: updated } : a)));
                          }}
                        />
                      </div>
                      <div className="col-md-3">
                        <div className="input-group input-group-sm">
                          <span className="input-group-text">Rate ₹</span>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="e.g. 28.5"
                            value={fab.fabricRate}
                            onChange={(e) => {
                              const updated = [...art.fabrics];
                              updated[fIdx].fabricRate = e.target.value;
                              setSelectedArticles(selectedArticles.map((a) => (a.id === art.id ? { ...a, fabrics: updated } : a)));
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 text-muted bg-light rounded-4 border border-dashed">
            Click on one or more article tiles above (e.g. Kurta) to configure fabric requirement.
          </div>
        )}
      </div>

      {/* =========================================================================
       * 3. CUSTOMERS & ORDERS (EXACT STRUCTURE AS IN USER SCREENSHOTS)
       * ========================================================================= */}
      <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white" style={{ borderTop: '4px solid #10b981' }}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div className="d-flex align-items-center gap-2">
            <div className="p-2 rounded-3 text-white d-flex align-items-center justify-content-center" style={{ background: '#10b981', width: '36px', height: '36px' }}>
              <i className="ti ti-users fs-5"></i>
            </div>
            <div>
              <h5 className="fw-bold text-dark mb-0">Customers &amp; Orders</h5>
              <p className="text-muted small mb-0">Add customers, select articles, and set color quantities</p>
            </div>
          </div>
          <button className="btn btn-sm btn-outline-success rounded-3 fw-semibold px-3" onClick={() => setShowNewCustomerModal(true)}>
            <i className="ti ti-user-plus me-1"></i> + New Customer
          </button>
        </div>

        {/* How many customers? */}
        <div className="mb-4">
          <label className="form-label fw-semibold small text-muted mb-2">How many customers?</label>
          <div className="d-flex gap-2 align-items-center">
            {[1, 2, 3, 4, 5, 6].map((num) => {
              const isSelected = customerCount === num;
              return (
                <button
                  key={num}
                  type="button"
                  className={`btn rounded-3 fw-bold transition ${
                    isSelected ? 'text-white shadow-sm' : 'btn-light border text-secondary'
                  }`}
                  style={{
                    width: '45px',
                    height: '42px',
                    background: isSelected ? '#10b981' : '#ffffff',
                    borderColor: isSelected ? '#10b981' : '#e2e8f0'
                  }}
                  onClick={() => handleCustomerCountChange(num)}
                >
                  {num}
                </button>
              );
            })}
          </div>
        </div>

        {/* Customer Accordion Cards or Empty State */}
        {customerOrders.length === 0 ? (
          <div
            className="p-5 rounded-4 text-center my-2"
            style={{
              border: '1.5px dashed #fcd34d',
              backgroundColor: '#fffbeb',
              borderRadius: '16px'
            }}
          >
            <div className="mb-2" style={{ color: '#f59e0b' }}>
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="d-inline-block">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
            <h6 className="fw-bold mb-1" style={{ color: '#b45309', fontSize: '16px' }}>
              Select how many customers
            </h6>
            <p className="small mb-0" style={{ color: '#d97706' }}>
              Click a number above to add customer boxes
            </p>
          </div>
        ) : (
          <div className="d-flex flex-column gap-3">
            {customerOrders.map((cust, cIdx) => {
            const summary = getCustomerSummary(cust);
            const isExpanded = expandedCustomerIdx === cIdx;

            return (
              <div key={cIdx} className="card border rounded-4 shadow-xs overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
                {/* Customer Accordion Header */}
                <div
                  className="p-3 bg-light d-flex justify-content-between align-items-center cursor-pointer transition"
                  onClick={() => setExpandedCustomerIdx(isExpanded ? -1 : cIdx)}
                  style={{ borderBottom: isExpanded ? '1px solid #e2e8f0' : 'none' }}
                >
                  <div className="d-flex align-items-center gap-3">
                    <div
                      className="rounded-circle text-white d-flex align-items-center justify-content-center fw-bold fs-6"
                      style={{ width: '36px', height: '36px', background: '#10b981' }}
                    >
                      {cIdx + 1}
                    </div>
                    <div>
                      <h6 className="fw-bold text-dark mb-0">Customer {cIdx + 1}</h6>
                      <span className="text-muted small">
                        {summary.articlesCount} articles &bull; {summary.colorsCount} colors &bull; {summary.totalPcs} pcs
                      </span>
                    </div>
                  </div>
                  <i className={`ti ti-chevron-${isExpanded ? 'up' : 'down'} fs-5 text-muted`}></i>
                </div>

                {/* Customer Accordion Body */}
                {isExpanded && (
                  <div className="p-4 bg-white">
                    {/* Select Customer */}
                    <div className="mb-3">
                      <label className="form-label fw-semibold small text-muted mb-1">Select Customer</label>
                      <select
                        className="form-select mb-2"
                        value={cust.customerId}
                        onChange={(e) => updateCustomerField(cIdx, 'customerId', e.target.value)}
                      >
                        <option value="">Choose from list...</option>
                        {allCustomers.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.type})
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Or type customer name directly"
                        value={cust.customName}
                        onChange={(e) => updateCustomerField(cIdx, 'customName', e.target.value)}
                      />
                    </div>

                    {/* Select Articles for this Customer */}
                    <div className="mb-4">
                      <label className="form-label fw-semibold small text-muted d-flex align-items-center gap-1 mb-2">
                        <i className="ti ti-shirt text-primary"></i> Select Articles for this Customer
                      </label>
                      <div className="d-flex flex-wrap gap-2">
                        {selectedArticles.map((art) => {
                          const isAssigned = (cust.assignedArticles || []).includes(art.name);
                          return (
                            <button
                              key={art.id}
                              type="button"
                              className={`btn btn-sm rounded-pill px-3 py-2 fw-semibold d-flex align-items-center gap-2 transition ${
                                isAssigned ? 'btn-primary shadow-xs' : 'btn-light border text-secondary'
                              }`}
                              onClick={() => toggleCustomerArticle(cIdx, art.name)}
                            >
                              <span>{art.icon} {art.name}</span>
                              {isAssigned && <i className="ti ti-check small"></i>}
                            </button>
                          );
                        })}
                        {selectedArticles.length === 0 && (
                          <span className="text-muted small">Select articles in Section 2 above to assign here.</span>
                        )}
                      </div>
                    </div>

                    {/* Colors & Quantities */}
                    <div className="mb-3">
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <label className="form-label fw-semibold small text-muted d-flex align-items-center gap-1 mb-0">
                          <i className="ti ti-palette text-purple"></i> Colors &amp; Quantities
                        </label>
                        <button
                          type="button"
                          className="btn btn-sm text-purple fw-semibold p-0"
                          onClick={() => alert('Add custom color to palette')}
                        >
                          + New Color
                        </button>
                      </div>

                      <div className="small text-muted mb-2">Select Colors (18 available)</div>
                      <div className="d-flex flex-wrap gap-2 mb-4">
                        {ALL_18_COLORS.map((col) => {
                          const isColorSelected = (cust.selectedColors || []).includes(col.name);
                          return (
                            <button
                              key={col.name}
                              type="button"
                              className={`btn btn-sm rounded-pill px-3 py-1 d-flex align-items-center gap-2 transition ${
                                isColorSelected ? 'btn-dark shadow-xs' : 'btn-light border text-secondary'
                              }`}
                              onClick={() => toggleCustomerColor(cIdx, col.name)}
                            >
                              <span
                                className="rounded-circle border"
                                style={{ width: '12px', height: '12px', backgroundColor: col.hex }}
                              ></span>
                              <span>{col.name}</span>
                              {isColorSelected && <i className="ti ti-check small text-white"></i>}
                            </button>
                          );
                        })}
                      </div>

                      {/* Selected Color Breakdown Boxes */}
                      {(cust.selectedColors || []).map((colorName) => {
                        const cfg = cust.colorConfigs[colorName] || {
                          useSets: false,
                          setQty: '',
                          activeSizes: [],
                          sizeQtys: {}
                        };
                        const colorObj = ALL_18_COLORS.find((c) => c.name === colorName) || { hex: '#333333' };

                        let colorTotalPieces = 0;
                        Object.values(cfg.sizeQtys || {}).forEach((q) => {
                          colorTotalPieces += parseInt(q, 10) || 0;
                        });

                        return (
                          <div key={colorName} className="card border p-3 rounded-4 mb-3 bg-light" style={{ borderColor: '#e2e8f0' }}>
                            {/* Color Header */}
                            <div className="d-flex align-items-center gap-2 mb-3">
                              <span
                                className="rounded-circle border"
                                style={{ width: '16px', height: '16px', backgroundColor: colorObj.hex }}
                              ></span>
                              <strong className="fs-6 text-dark">{colorName}</strong>
                            </div>

                            {/* Use Sets? Toggle */}
                            <div className="d-flex align-items-center justify-content-between p-2 px-3 bg-white rounded-3 border mb-3">
                              <div className="d-flex align-items-center gap-2 small fw-semibold text-secondary">
                                <i className="ti ti-layers-subtract text-purple fs-5"></i>
                                <span>Use Sets?</span>
                              </div>
                              <div className="btn-group btn-group-sm rounded-3 overflow-hidden" role="group">
                                <button
                                  type="button"
                                  className={`btn px-3 fw-bold ${!cfg.useSets ? 'btn-dark text-white' : 'btn-light text-secondary'}`}
                                  onClick={() => updateColorConfig(cIdx, colorName, { useSets: false })}
                                >
                                  No
                                </button>
                                <button
                                  type="button"
                                  className={`btn px-3 fw-bold ${cfg.useSets ? 'text-white' : 'btn-light text-secondary'}`}
                                  style={{ background: cfg.useSets ? '#8b5cf6' : '' }}
                                  onClick={() => updateColorConfig(cIdx, colorName, { useSets: true })}
                                >
                                  Yes
                                </button>
                              </div>
                            </div>

                            {/* If Use Sets is True */}
                            {cfg.useSets && (
                              <div className="mb-3">
                                <label className="form-label small text-muted mb-1">
                                  Quantity per size (will auto-fill when you select sizes)
                                </label>
                                <div className="input-group input-group-sm" style={{ maxWidth: '280px' }}>
                                  <input
                                    type="text"
                                    className="form-control rounded-start-3"
                                    placeholder="e.g., 100"
                                    value={cfg.setQty}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      const num = parseInt(val, 10) || 0;
                                      const updatedQtys = {};
                                      (cfg.activeSizes || []).forEach((s) => {
                                        updatedQtys[s] = num;
                                      });
                                      updateColorConfig(cIdx, colorName, { setQty: val, sizeQtys: updatedQtys });
                                    }}
                                  />
                                  <span className="input-group-text bg-white text-muted">pcs per size</span>
                                </div>
                              </div>
                            )}

                            {/* Select Sizes & Quantities */}
                            <div className="mb-3">
                              <label className="form-label small text-muted mb-2">
                                {cfg.useSets ? 'Select Sizes (optional - will use sets quantity)' : 'Select Sizes & Quantities *'}
                              </label>
                              <div className="d-flex flex-wrap gap-2 mb-3">
                                {ALL_SIZES.map((sz) => {
                                  const isActive = (cfg.activeSizes || []).includes(sz);
                                  return (
                                    <button
                                      key={sz}
                                      type="button"
                                      className={`btn btn-sm rounded-3 fw-bold transition ${
                                        isActive ? 'text-white shadow-xs' : 'btn-white border text-secondary bg-white'
                                      }`}
                                      style={{
                                        minWidth: '42px',
                                        height: '38px',
                                        background: isActive ? '#6366f1' : '#ffffff',
                                        borderColor: isActive ? '#6366f1' : '#e2e8f0'
                                      }}
                                      onClick={() => toggleColorSize(cIdx, colorName, sz)}
                                    >
                                      {sz}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Size Steppers ([-] 0 [+] [x]) for active sizes */}
                              {(cfg.activeSizes || []).length > 0 && (
                                <div className="d-flex flex-wrap gap-2 pt-2 border-top">
                                  {cfg.activeSizes.map((sz) => (
                                    <div
                                      key={sz}
                                      className="d-flex align-items-center gap-1 p-1 px-2 rounded-3"
                                      style={{ background: '#ede9fe', border: '1px solid #ddd6fe' }}
                                    >
                                      <strong className="text-primary px-1">{sz}</strong>
                                      <button
                                        type="button"
                                        className="btn btn-xs btn-white rounded-circle p-0 d-flex align-items-center justify-content-center border"
                                        style={{ width: '22px', height: '22px' }}
                                        onClick={() => updateSizeQty(cIdx, colorName, sz, -10, true)}
                                      >
                                        -
                                      </button>
                                      <input
                                        type="text"
                                        className="form-control form-control-sm text-center p-0 bg-white border-0 fw-bold"
                                        style={{ width: '45px', height: '24px' }}
                                        value={cfg.sizeQtys[sz] ?? 0}
                                        onChange={(e) => updateSizeQty(cIdx, colorName, sz, e.target.value, false)}
                                      />
                                      <button
                                        type="button"
                                        className="btn btn-xs btn-white rounded-circle p-0 d-flex align-items-center justify-content-center border"
                                        style={{ width: '22px', height: '22px' }}
                                        onClick={() => updateSizeQty(cIdx, colorName, sz, 10, true)}
                                      >
                                        +
                                      </button>
                                      <button
                                        type="button"
                                        className="btn btn-xs text-danger p-0 ms-1"
                                        onClick={() => removeSize(cIdx, colorName, sz)}
                                      >
                                        &times;
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Color Total Badge */}
                            <div className="d-flex justify-content-end">
                              <span className="badge rounded-3 p-2 px-3 fw-bold d-flex align-items-center gap-1" style={{ background: '#e0e7ff', color: '#4338ca' }}>
                                <i className="ti ti-box"></i> {colorTotalPieces} pcs
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>

      {/* =========================================================================
       * 4. OVERALL AGGREGATE QUANTITY MATRIX
       * ========================================================================= */}
      {Object.keys(aggregateColorMatrix).length > 0 && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2" style={{ color: '#1e1b4b' }}>
              <span className="badge text-white rounded-3 px-2 py-1" style={{ background: '#1e1b4b' }}>4</span> Size Series &amp; Quantity Matrix Summary
            </h5>
            <strong className="fs-6" style={{ color: '#4f46e5' }}>
              Grand Total: {grandTotalGarmentPieces} pcs
            </strong>
          </div>

          <div className="table-responsive">
            <table className="table table-bordered text-center align-middle mb-0">
              <thead className="bg-light text-uppercase text-secondary" style={{ fontSize: '11px' }}>
                <tr>
                  <th className="text-start py-3 px-3">COLOUR</th>
                  {['S', 'M', 'L', 'XL', '2XL'].map((sz) => (
                    <th key={sz} className="py-3 px-3">SIZE {sz}</th>
                  ))}
                  <th className="py-3 px-3">TOTAL</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(aggregateColorMatrix).map(([color, szData]) => (
                  <tr key={color}>
                    <td className="text-start fw-bold text-dark px-3">{color}</td>
                    {['S', 'M', 'L', 'XL', '2XL'].map((sz) => (
                      <td key={sz} className="font-monospace text-secondary">
                        {szData[sz] ?? 0}
                      </td>
                    ))}
                    <td className="fw-bold text-dark font-monospace">{szData.Total || 0}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-light fw-bold">
                <tr>
                  <td className="text-start px-3 text-dark">Grand Total</td>
                  <td colSpan={5}></td>
                  <td className="fs-6 font-monospace" style={{ color: '#4f46e5' }}>
                    {grandTotalGarmentPieces} pcs
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
       * 5. FABRIC CONSUMPTION & COST ENGINE
       * ========================================================================= */}
      {selectedArticles.length > 0 && Object.keys(aggregateColorMatrix).length > 0 && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6 className="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
              <span className="badge bg-primary text-white rounded-circle p-1">5</span> Fabric Consumption & Cost Engine
            </h6>
            <span className="badge bg-success-subtle text-success">
              Greige: {totalGreigeFabric}m | Dyed: {totalDyedFabric}m
            </span>
          </div>

          <div className="table-responsive">
            <table className="table table-sm table-bordered align-middle">
              <thead className="bg-light">
                <tr>
                  <th>Article</th>
                  <th>Fabric Quality</th>
                  <th>Width</th>
                  <th>Colour</th>
                  <th className="text-end">Consumption/Pc</th>
                  <th className="text-end">Pieces</th>
                  <th className="text-end">Total Dyed</th>
                  <th className="text-end">Total Greige</th>
                </tr>
              </thead>
              <tbody>
                {fabricConsumptions.map((fc, idx) => (
                  <tr key={idx}>
                    <td className="fw-semibold">{fc.articleName}</td>
                    <td>{fc.fabricQuality}</td>
                    <td>{fc.width}</td>
                    <td>{fc.colorName}</td>
                    <td className="text-end font-monospace">{fc.consumptionPerGarment} m</td>
                    <td className="text-end">{fc.pieces}</td>
                    <td className="text-end text-success fw-semibold font-monospace">{fc.totalDyed} m</td>
                    <td className="text-end text-primary fw-bold font-monospace">{fc.totalGreige} m</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
       * 6. ACCESSORIES SELECTION & CONFIGURATION (BOM) - (Hidden until requested)
       * ========================================================================= */}
      {showBomSection && (
        <div className="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white" style={{ borderTop: '4px solid #f59e0b' }}>
          <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div className="d-flex align-items-center gap-2">
              <div className="p-2 rounded-3 text-white d-flex align-items-center justify-content-center" style={{ background: '#f59e0b', width: '36px', height: '36px' }}>
                <i className="ti ti-puzzle fs-5"></i>
              </div>
              <div>
                <h5 className="fw-bold text-dark mb-0">Accessories Selection &amp; Configuration (BOM)</h5>
                <p className="text-muted small mb-0">Select trims, buttons, laces, threads, and packaging for articles</p>
              </div>
            </div>
            <div className="d-flex align-items-center gap-2">
              <span className="badge p-2 px-3 fw-bold rounded-3" style={{ background: '#fef3c7', color: '#b45309' }}>
                <i className="ti ti-coins me-1"></i> BOM Total: ₹{totalAccessoriesCost}
              </span>
              <div className="dropdown">
                <button className="btn btn-sm btn-outline-warning text-dark dropdown-toggle rounded-3 fw-semibold px-3" type="button" data-bs-toggle="dropdown">
                  <i className="ti ti-plus me-1"></i> + Quick Add Trims
                </button>
                <ul className="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 p-2" style={{ maxHeight: '320px', overflowY: 'auto' }}>
                  <li className="dropdown-header text-uppercase small fw-bold text-muted">Common Presets</li>
                  {availableAccessoryPresets.map((preset, pIdx) => (
                    <li key={pIdx}>
                      <button
                        className="dropdown-item rounded-2 py-1 small d-flex justify-content-between align-items-center"
                        type="button"
                        onClick={() => addAccessoryRow(preset)}
                      >
                        <span><strong>[{preset.category}]</strong> {preset.name}</span>
                        <span className="text-muted ms-2">₹{preset.rate}/{preset.unit}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Quick Category Filter / Selector */}
          <div className="d-flex gap-2 mb-3 flex-wrap align-items-center">
            <span className="small fw-semibold text-muted">Filter Categories:</span>
            {['All', 'Buttons', 'Lace', 'Thread', 'Labels', 'Elastic', 'Zipper', 'Packaging'].map((cat) => (
              <button
                key={cat}
                type="button"
                className={`btn btn-xs rounded-pill px-3 py-1 fw-semibold transition ${
                  selectedAccessoryCategory === cat ? 'btn-dark text-white' : 'btn-light border text-secondary'
                }`}
                style={{ fontSize: '12px' }}
                onClick={() => setSelectedAccessoryCategory(cat)}
              >
                {cat}
              </button>
            ))}
            <button
              type="button"
              className="btn btn-xs btn-outline-primary rounded-pill px-3 py-1 ms-auto fw-semibold"
              style={{ fontSize: '12px' }}
              onClick={() => addAccessoryRow({ category: 'Custom', name: 'Custom Trim Item', unit: 'Pcs', consumption: 1, bufferPercent: 5, rate: 0 })}
            >
              + Add Custom Item
            </button>
          </div>

          {/* Accessories BOM Table */}
          {calculatedAccessories.length > 0 ? (
            <div className="table-responsive">
              <table className="table table-sm table-bordered align-middle text-center mb-0">
                <thead className="bg-light text-uppercase text-secondary" style={{ fontSize: '11px' }}>
                  <tr>
                    <th className="text-start py-2 px-3">Accessory / Item</th>
                    <th className="py-2">Category</th>
                    <th className="py-2">Article</th>
                    <th className="py-2">Colour Applicability</th>
                    <th className="py-2" style={{ width: '90px' }}>Cons / Pc</th>
                    <th className="py-2" style={{ width: '70px' }}>Unit</th>
                    <th className="py-2" style={{ width: '80px' }}>Buffer %</th>
                    <th className="py-2">Order Pcs</th>
                    <th className="py-2 fw-bold text-primary">Req. Qty</th>
                    <th className="py-2" style={{ width: '90px' }}>Rate (₹)</th>
                    <th className="py-2 fw-bold text-success">Amount (₹)</th>
                    <th className="py-2" style={{ width: '40px' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {calculatedAccessories
                    .filter((acc) => selectedAccessoryCategory === 'All' || acc.category === selectedAccessoryCategory)
                    .map((acc) => (
                      <tr key={acc.id}>
                        {/* Name */}
                        <td className="text-start px-3">
                          <input
                            type="text"
                            className="form-control form-control-sm border-0 bg-transparent fw-semibold text-dark p-0"
                            value={acc.name}
                            onChange={(e) => updateAccessoryRow(acc.id, 'name', e.target.value)}
                          />
                        </td>
                        {/* Category */}
                        <td>
                          <span className="badge bg-light text-dark border px-2 py-1" style={{ fontSize: '10px' }}>
                            {acc.category}
                          </span>
                        </td>
                        {/* Article */}
                        <td>
                          <select
                            className="form-select form-select-sm py-0"
                            style={{ fontSize: '12px' }}
                            value={acc.articleName}
                            onChange={(e) => updateAccessoryRow(acc.id, 'articleName', e.target.value)}
                          >
                            <option value="All Articles">All Articles</option>
                            {selectedArticles.map((a) => (
                              <option key={a.id} value={a.name}>{a.name}</option>
                            ))}
                          </select>
                        </td>
                        {/* Colour Applicability */}
                        <td>
                          <select
                            className="form-select form-select-sm py-0"
                            style={{ fontSize: '12px' }}
                            value={acc.colorMapping}
                            onChange={(e) => updateAccessoryRow(acc.id, 'colorMapping', e.target.value)}
                          >
                            <option value="ALL">All Colours (Mirror)</option>
                            {Object.keys(aggregateColorMatrix).map((col) => (
                              <option key={col} value={col}>{col} ({aggregateColorMatrix[col]?.Total || 0} pcs)</option>
                            ))}
                          </select>
                        </td>
                        {/* Consumption */}
                        <td>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            className="form-control form-control-sm text-center"
                            value={acc.consumptionPerGarment}
                            onChange={(e) => updateAccessoryRow(acc.id, 'consumptionPerGarment', e.target.value)}
                          />
                        </td>
                        {/* Unit */}
                        <td>
                          <select
                            className="form-select form-select-sm py-0 text-center"
                            style={{ fontSize: '11px' }}
                            value={acc.unit}
                            onChange={(e) => updateAccessoryRow(acc.id, 'unit', e.target.value)}
                          >
                            <option value="Pcs">Pcs</option>
                            <option value="Mtr">Mtr</option>
                            <option value="Box">Box</option>
                            <option value="Cone">Cone</option>
                            <option value="Gross">Gross</option>
                            <option value="Set">Set</option>
                          </select>
                        </td>
                        {/* Buffer % */}
                        <td>
                          <input
                            type="number"
                            min="0"
                            max="100"
                            className="form-control form-control-sm text-center"
                            value={acc.bufferPercent}
                            onChange={(e) => updateAccessoryRow(acc.id, 'bufferPercent', e.target.value)}
                          />
                        </td>
                        {/* Order Pieces */}
                        <td className="font-monospace text-secondary fw-semibold">
                          {acc.targetPieces}
                        </td>
                        {/* Required Qty */}
                        <td className="font-monospace fw-bold text-primary">
                          {acc.totalRequired} {acc.unit}
                        </td>
                        {/* Rate */}
                        <td>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            className="form-control form-control-sm text-center"
                            value={acc.rate}
                            onChange={(e) => updateAccessoryRow(acc.id, 'rate', e.target.value)}
                          />
                        </td>
                        {/* Total Amount */}
                        <td className="font-monospace fw-bold text-success">
                          ₹{acc.totalAmount}
                        </td>
                        {/* Delete */}
                        <td>
                          <button
                            type="button"
                            className="btn btn-xs text-danger p-0 border-0 bg-transparent"
                            onClick={() => removeAccessoryRow(acc.id)}
                            title="Remove item"
                          >
                            <i className="ti ti-trash fs-6"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
                <tfoot className="bg-light fw-bold">
                  <tr>
                    <td colSpan={8} className="text-end px-3">Total Estimated Accessories (BOM) Cost:</td>
                    <td colSpan={4} className="text-end px-3 fs-6 font-monospace" style={{ color: '#059669' }}>
                      ₹{totalAccessoriesCost}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          ) : (
            <div className="p-4 rounded-4 text-center border border-dashed bg-light text-muted">
              <i className="ti ti-puzzle fs-2 text-warning d-block mb-2"></i>
              <p className="mb-2 fw-semibold">No accessories configured yet</p>
              <span className="small">Use the "+ Quick Add Trims" dropdown or "+ Add Custom Item" button above to configure BOM for this style.</span>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
       * 7. BASKET ACTION BAR (Bottom Action Bar)
       * ========================================================================= */}
      <div className="card border-0 shadow-lg rounded-4 p-3 bg-dark text-white d-flex flex-row justify-content-between align-items-center flex-wrap gap-3">
        <div className="d-flex align-items-center gap-3">
          <div className="p-2 bg-primary rounded-3 text-white fs-4">
            <i className="ti ti-shopping-cart"></i>
          </div>
          <div>
            <h6 className="fw-bold mb-0 text-white">Ready for Procurement</h6>
            <span className="text-light opacity-75 small">
              {totalGreigeFabric}m Greige Fabric &bull; {grandTotalGarmentPieces} Total Garments
            </span>
          </div>
        </div>
        <div className="d-flex gap-2">
          <button
            className="btn btn-primary rounded-3 px-3 fw-semibold d-flex align-items-center gap-2 shadow-sm"
            onClick={() => handleFinalSave('Create PO')}
          >
            <i className="ti ti-file-text"></i> Create PO
          </button>
          <button
            className="btn btn-outline-light rounded-3 px-3 fw-semibold d-flex align-items-center gap-2"
            onClick={() => handleFinalSave('Send to Process')}
          >
            <i className="ti ti-brush"></i> Send to Process
          </button>
          <button
            className="btn btn-outline-light rounded-3 px-3 fw-semibold d-flex align-items-center gap-2"
            onClick={() => handleFinalSave('Order Material')}
          >
            <i className="ti ti-box"></i> Order Material
          </button>
        </div>
      </div>

      {/* Inline Modals */}
      {showNewCustomerModal && (
        <CustomerMasterView
          isInline={true}
          onSaveInline={(newCust) => {
            setAllCustomers([...allCustomers, newCust]);
            setShowNewCustomerModal(false);
          }}
          onCloseInline={() => setShowNewCustomerModal(false)}
        />
      )}

      {showNewArticleModal && (
        <ArticleMasterView
          isInline={true}
          onSaveInline={(newArt) => {
            toggleArticle(newArt);
            setShowNewArticleModal(false);
          }}
          onCloseInline={() => setShowNewArticleModal(false)}
        />
      )}
    </div>
  );
}
